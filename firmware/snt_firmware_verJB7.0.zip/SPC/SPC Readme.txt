Place your SPC files in this directory.   

The SPC player can play both regular .SPC files, and a newer "SPC 2" format, which is a packed version of SPC files that include multiple sub-tunes.  A document on SPC 2 is included in this directory.

The SPC player CANNOT play .RSN archives, which are .RAR format.

